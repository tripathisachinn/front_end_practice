import React from 'react'

export default function Home() {
    return (
        <div id='home'>
            This page is about the order of Mounting Updating and Unmounting in React Lifecycle methods!
        </div>
    )
}
